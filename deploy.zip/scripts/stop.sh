#!/bin/bash
pm2 stop next_app || true
